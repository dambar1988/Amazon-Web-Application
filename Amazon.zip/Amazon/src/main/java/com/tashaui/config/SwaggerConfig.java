package com.tashaui.config;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.VendorExtension;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

	
	/**  
	 * It will detect all controller
	 *     
	 */
	@Bean
	public Docket createSwaggerDocket() 
	{
		return new Docket(DocumentationType.SWAGGER_2) 

				.select()
				.apis(RequestHandlerSelectors
						.basePackage("com.tashaui.controller")) 
				//select rest controller from this package
				.paths(PathSelectors.regex("/rest.*"))
				.build()
				.apiInfo(apiInfo());
	}

	@SuppressWarnings("rawtypes")
	private ApiInfo apiInfo() {
		return new ApiInfo(
		"Amazon Application", 
		"Amazon APP", "3.2GA", 
		"https://tashaui.in/", 
		new Contact("Dambar Rawal", 
		   "https://www.tashaui.com", 
		     "dtdkds88@gmail.com"
		), 
		" ", 
		" ",
		new ArrayList<VendorExtension>());
	}
}
