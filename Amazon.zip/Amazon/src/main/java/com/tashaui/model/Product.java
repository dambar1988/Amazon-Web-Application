package com.tashaui.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import lombok.Data;
@Data
@Entity
public class Product {

	@Id
	@GeneratedValue
	private Integer prodId;
	
	//@Size(max = 2)
	private String prodName;
	private Double prodCost;
	private String prodType;
	@Size(max = 400)
	private String prodDescription;
	
}
