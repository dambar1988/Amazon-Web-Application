package com.tashaui.service.impl;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tashaui.model.Product;
import com.tashaui.repo.ProductRepository;
import com.tashaui.service.IProductService;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	private ProductRepository repo;

	@Override
	@Transactional
	public Integer saveProduct(Product product) {
		
		return repo.save(product).getProdId();
		
	}

	@Override
	@Transactional(readOnly = true)
	public List<Product> getAllProduct() {
		List<Product> list = repo.findAll();
		Collections.sort(list,
				(o1, o2) -> o1.getProdName().compareTo(o2.getProdName()) // ASC based on PID
		);

		return list;
	}

	@Override
	public void deleteProduct(Integer prodId) {
		repo.deleteById(prodId);
	}

	@Override
	public Optional<Product> getOneProduct(Integer prodId) {
		
		return repo.findById(prodId);
	}

	@Override
	public void updateProduct(Product product) {

		repo.save(product);
	}

	@Override
	public boolean isProductExist(Integer prodId) {
		// TODO Auto-generated method stub
		return repo.existsById(prodId);
	}

}
