package com.tashaui.service;

import java.util.List;
import java.util.Optional;

import com.tashaui.model.Product;

public interface IProductService {

	public Integer saveProduct(Product product);
	public List<Product> getAllProduct();
	public void deleteProduct(Integer pId);
	public Optional<Product> getOneProduct(Integer pId);
	public void updateProduct(Product product);	
	boolean isProductExist(Integer pId);
}