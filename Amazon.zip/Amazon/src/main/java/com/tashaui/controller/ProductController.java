package com.tashaui.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tashaui.model.Product;
import com.tashaui.service.IProductService;
/**
 * 
 * @author Dambar Rawal
 *
 */
@RestController
@RequestMapping("/rest/product")
public class ProductController {

	private Logger log = LoggerFactory.getLogger(ProductController.class);

	@Autowired
	private IProductService service;

	/**
	 * Save Product data into Database.
	 * return message.
	 */
	@PostMapping("/save")
	public ResponseEntity<String> saveProduct(@RequestBody Product product) {
		log.info("Method for product data to save");
		ResponseEntity<String> response = null;
		try {
			log.info("Save Operation");
			Integer id = service.saveProduct(product);
			log.debug("Product saved with id " + id);
			String body = "Product '" + id + "' created";
			//201
			response = new ResponseEntity<String>(body, HttpStatus.CREATED);
			log.info("Sucess response constructed");
		} catch (Exception e) {

			//For 500 error
			response = new ResponseEntity<String>("Unable to save product", HttpStatus.INTERNAL_SERVER_ERROR); 
			e.printStackTrace();
		}
		log.info("About to Exist save method with Response");
		return response;
	}

	/**
	 * Fetch all row from database using Service 
	 * Sort data using pname , return as
	 */
	@GetMapping("/all")
	public ResponseEntity<?> getAllProducts() {
		log.info("Method to fetch Products data");
		ResponseEntity<?> response = null;
		try {
			log.info("About to call fetch product service");
			List<Product> list = service.getAllProduct();
			if (list != null && !list.isEmpty()) {
				log.info("Data is not empty=>" + list.size());
				list.sort((s1, s2) -> s1.getProdName().compareTo(s2.getProdName()));

				response = new ResponseEntity<List<Product>>(list, HttpStatus.OK);
			} else {
				log.info("No Product exist: size" + list.size());
				response = new ResponseEntity<String>("No Products Found", HttpStatus.OK);
			}
		} catch (Exception e) {

			//for internal server error 500
			response = new ResponseEntity<String>("Unable to Fetch Products", HttpStatus.INTERNAL_SERVER_ERROR); 
			e.printStackTrace();
		}

		return response;
	}

	/***
	 * Get one Product object based on ID 
	 * return Product object else provide.
	 */
	@GetMapping("/one/{id}")
	public ResponseEntity<?> getOne(@PathVariable Integer prodId) {
		log.info("Entered into Get one Product method");
		ResponseEntity<?> response = null;
		try {
			log.info("About to make service call to fetch one record");
			Optional<Product> opt = service.getOneProduct(prodId);
			if (opt.isPresent()) {
				log.info("Product exist:" + prodId);
				response = new ResponseEntity<Product>(opt.get(), HttpStatus.OK);
			} else {
				log.warn("Given Product id not exist:" + prodId);
				response = new ResponseEntity<String>("Product '" + prodId + "' not exist", HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			log.error("Unable to process request fetch " + e.getMessage());
			response = new ResponseEntity<String>("Unable to process product fetch", HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}

		return response;
	}

	@DeleteMapping("/remove/{id}")
	public ResponseEntity<String> removeProduct(@PathVariable Integer prodId) {

		log.info("Entered into delete method");
		ResponseEntity<String> response = null;

		try {

			log.info("About to make service call for data check");
			boolean exist = service.isProductExist(prodId);
			if (exist) {
				service.deleteProduct(prodId);
				log.info("Product exist with given id and deleted=>" + prodId);
				response = new ResponseEntity<String>("Product '" + prodId + "' deleted", HttpStatus.OK);
			} else {
				log.warn("Given Product id not exist :" + prodId);
				response = new ResponseEntity<String>("Product '" + prodId + "' not exist", HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			log.error("Unable to perform Delete Operation :" + e.getMessage());
			response = new ResponseEntity<String>("Unable to delete", HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}

		return response;
	}

}
